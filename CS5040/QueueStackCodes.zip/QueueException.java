
public class QueueException extends RuntimeException{

	QueueException(){
		super();
	}
	QueueException(String s){
		super(s);
	}
}
