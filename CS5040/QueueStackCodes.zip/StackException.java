
public class StackException extends RuntimeException{

	StackException(){
		super();
	}
	StackException(String s){
		super(s);
	}
}
